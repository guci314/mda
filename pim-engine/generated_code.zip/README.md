# user-management

User management system with authentication and authorization

## Generated with PIM Engine

This project was automatically generated from a PIM (Platform Independent Model) using the PIM Execution Engine.

## Features

- RESTful API built with FastAPI
- PostgreSQL database with SQLAlchemy ORM
- Pydantic for data validation
- JWT authentication ready
- Docker support
- Comprehensive test suite

## Quick Start

### Prerequisites

- Python 3.11+
- PostgreSQL
- Docker (optional)

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd user-management
```

2. Create virtual environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies
```bash
pip install -r requirements.txt
```

4. Set up environment variables
```bash
cp .env.example .env
# Edit .env with your configuration
```

5. Run migrations
```bash
alembic upgrade head
```

6. Start the application
```bash
uvicorn app.main:app --reload
```

The API will be available at http://localhost:8000

## API Documentation

Once the application is running, you can access:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Testing

Run tests with pytest:
```bash
pytest
```

## Docker

Build and run with Docker:
```bash
docker build -t user-management .
docker run -p 8000:8000 user-management
```

## Project Structure

```
.
├── app/
│   ├── api/          # API routes
│   ├── core/         # Core configuration
│   ├── models/       # Database models
│   ├── schemas/      # Pydantic schemas
│   ├── services/     # Business logic
│   └── main.py       # Application entry point
├── tests/            # Test suite
├── docs/             # Documentation
├── requirements.txt  # Python dependencies
├── Dockerfile        # Docker configuration
└── README.md         # This file
```

## License

This project is generated code and is provided as-is.
