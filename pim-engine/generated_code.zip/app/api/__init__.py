from fastapi import APIRouter

from .routes.userservice import router as userservice_router

api_router = APIRouter()

api_router.include_router(userservice_router)
