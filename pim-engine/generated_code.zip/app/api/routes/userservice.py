from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ...core.database import get_db
from ...services import UserService
from ...schemas import *

router = APIRouter(
    prefix="/user",
    tags=["UserService"]
)


@router.post("register-user", response_model=EntityResponse)
async def registerUser(
    data: EntityCreate,
    db: Session = Depends(get_db)
):
    """Register a new user with validation"""
    service = UserService(db)
    return await service.registerUser(data)



@router.post("authenticate-user", response_model=EntityResponse)
async def authenticateUser(
    data: EntityCreate,
    db: Session = Depends(get_db)
):
    """Authenticate user with email and password"""
    service = UserService(db)
    return await service.authenticateUser(data)



@router.put("/{id}", response_model=EntityResponse)
async def updateUserProfile(
    id: int,
    data: EntityUpdate,
    db: Session = Depends(get_db)
):
    """Update user profile information"""
    service = UserService(db)
    return await service.updateUserProfile(id, data)
