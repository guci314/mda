from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, HttpUrl, UUID4


class UserBase(BaseModel):
    """Base schema for User"""
    name: str
    email: str
    phone: Optional[str]
    status: str
    role: str
    lastLogin: Optional[datetime]



class UserCreate(UserBase):
    """Schema for creating User"""
    pass


class UserUpdate(BaseModel):
    """Schema for updating User"""
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    status: Optional[str] = None
    role: Optional[str] = None
    lastLogin: Optional[datetime] = None



class UserResponse(UserBase):
    """Schema for User response"""
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True