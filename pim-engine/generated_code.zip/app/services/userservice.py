from fastapi import HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
import logging
import re
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import AsyncGenerator, Optional

import bcrypt
import jwt
from fastapi import APIRouter, Depends, FastAPI, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr, Field, field_validator
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Enum as SAEnum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session

# --- Configuration ---
# In a real application, these should be loaded from a .env file or environment variables
DATABASE_URL = "sqlite:///./user_management.db"
SECRET_KEY = "your-super-secret-key-that-is-long-and-random"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

# --- Logging Setup ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Database Setup ---
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db() -> AsyncGenerator[Session, None]:
    """Dependency to get a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# --- Enums ---
class UserStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"

class UserRole(str, Enum):
    ADMIN = "admin"
    USER = "user"

# --- SQLAlchemy ORM Model ---
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    phone = Column(String, nullable=True)
    hashed_password = Column(String, nullable=False)
    status = Column(SAEnum(UserStatus), nullable=False, default=UserStatus.ACTIVE)
    role = Column(SAEnum(UserRole), nullable=False, default=UserRole.USER)
    last_login = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=datetime.now(timezone.utc), onupdate=datetime.now(timezone.utc))

# --- Pydantic Schemas ---
class UserBase(BaseModel):
    name: str
    email: EmailStr
    phone: Optional[str] = None

class UserCreate(UserBase):
    password: str = Field(..., min_length=8)

class UserUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None

class UserResponse(UserBase):
    id: int
    status: UserStatus
    role: UserRole
    last_login: Optional[datetime] = None

    class Config:
        from_attributes = True

class AuthTokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int

# --- Security ---
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def hash_password(password: str) -> str:
    """Hashes a password using bcrypt."""
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifies a plain password against a hashed one."""
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Creates a JWT access token."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# --- UserService: Business Logic ---
class UserService:
    def __init__(self, db: Session = Depends(get_db)):
        self.db = db

    async def registerUser(self, userData: UserCreate) -> User:
        """
        Register a new user with validation.
        - Validates email format (handled by Pydantic's EmailStr).
        - Checks for email uniqueness.
        - Hashes password and creates user record.
        """
        logger.info(f"Attempting to register user with email: {userData.email}")

        # 1. Validate Email Format (Implicitly done by Pydantic's EmailStr)
        # 2. Check Email Uniqueness
        existing_user = self.db.query(User).filter(User.email == userData.email).first()
        if existing_user:
            logger.warning(f"Registration failed: email {userData.email} already exists.")
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email already registered",
            )

        # 3. Create User Record
        hashed_password = hash_password(userData.password)
        db_user = User(
            name=userData.name,
            email=userData.email,
            phone=userData.phone,
            hashed_password=hashed_password,
            status=UserStatus.ACTIVE,
            role=UserRole.USER
        )
        self.db.add(db_user)
        self.db.commit()
        self.db.refresh(db_user)

        # 4. TODO: Send Welcome Email (e.g., via a background task)
        logger.info(f"User {userData.email} registered successfully with ID {db_user.id}.")
        return db_user

    async def authenticateUser(self, email: str, password: str) -> AuthTokenResponse:
        """
        Authenticate user with email and password.
        - Validates credentials.
        - Checks user status.
        - Returns a JWT token on success.
        """
        logger.info(f"Authentication attempt for user: {email}")

        # 1. Validate Credentials
        user = self.db.query(User).filter(User.email == email).first()
        if not user or not verify_password(password, user.hashed_password):
            logger.warning(f"Invalid credentials for user: {email}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password",
                headers={"WWW-Authenticate": "Bearer"},
            )

        # 2. Check User Status
        if user.status != UserStatus.ACTIVE:
            logger.warning(f"Authentication failed for inactive user: {email} (status: {user.status})")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Account is not active. Please contact support.",
            )

        # 3. Update last login and generate token
        user.last_login = datetime.now(timezone.utc)
        self.db.commit()

        expires_in = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": user.email, "role": user.role.value},
            expires_delta=expires_in
        )

        logger.info(f"User authenticated successfully: {email}")
        return AuthTokenResponse(
            access_token=access_token,
            expires_in=int(expires_in.total_seconds())
        )

    async def updateUserProfile(self, userId: int, profileData: UserUpdate, current_user_email: str) -> User:
        """
        Update user profile information.
        - Validates that the user exists.
        - Validates that the current user has permission to update.
        """
        logger.info(f"User {current_user_email} attempting to update profile for user ID: {userId}")

        # 1. Validate User Exists
        user_to_update = self.db.query(User).filter(User.id == userId).first()
        if not user_to_update:
            logger.error(f"Update failed: User with ID {userId} not found.")
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

        current_user = self.db.query(User).filter(User.email == current_user_email).first()

        # 2. Validate Update Permissions
        if user_to_update.id != current_user.id and current_user.role != UserRole.ADMIN:
            logger.warning(f"Permission denied: User {current_user.email} cannot update profile of user {user_to_update.email}.")
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to update this profile")

        # 3. Update Profile
        update_data = profileData.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(user_to_update, key, value)

        self.db.commit()
        self.db.refresh(user_to_update)
        logger.info(f"Profile for user ID {userId} updated successfully by {current_user_email}.")
        return user_to_update

# --- FastAPI Router ---
router = APIRouter(
    prefix="/users",
    tags=["User Management"],
)

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    """Dependency to get the current user from a JWT token."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except jwt.PyJWTError:
        raise credentials_exception
    
    user = db.query(User).filter(User.email == email).first()
    if user is None:
        raise credentials_exception
    if user.status != UserStatus.ACTIVE:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="User is not active")
    return user

@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register_user_endpoint(
    userData: UserCreate,
    service: UserService = Depends(UserService)
):
    """Endpoint to register a new user."""
    return await service.registerUser(userData)

@router.post("/token", response_model=AuthTokenResponse)
async def login_for_access_token(
    form_data: OAuth2PasswordRequestForm = Depends(),
    service: UserService = Depends(UserService)
):
    """Endpoint to authenticate and get a JWT token."""
    return await service.authenticateUser(email=form_data.username, password=form_data.password)

@router.put("/{user_id}", response_model=UserResponse)
async def update_user_profile_endpoint(
    user_id: int,
    profileData: UserUpdate,
    current_user: User = Depends(get_current_user),
    service: UserService = Depends(UserService)
):
    """Endpoint to update a user's profile. Requires authentication."""
    return await service.updateUserProfile(
        userId=user_id,
        profileData=profileData,
        current_user_email=current_user.email
    )

@router.get("/me", response_model=UserResponse)
async def read_users_me(current_user: User = Depends(get_current_user)):
    """Endpoint to get the current authenticated user's profile."""
    return current_user

# --- Main FastAPI App ---
app = FastAPI(
    title="User Management Service",
    description="A complete FastAPI service for user management with authentication and authorization.",
    version="1.0.0"
)

# Create database tables on startup
@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)

app.include_router(router)

# To run this application:
# 1. Install dependencies: pip install "fastapi[all]" sqlalchemy pydantic python-jose[cryptography] passlib[bcrypt]
# 2. Save the code as `user_service.py`
# 3. Run with uvicorn: uvicorn user_service:app --reload