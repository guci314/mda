# user-management API Documentation

## UserService

Base URL: `/user`

### registerUser

- **Method**: `POST`
- **Path**: `register-user`
- **Description**: Register a new user with validation

### authenticateUser

- **Method**: `POST`
- **Path**: `authenticate-user`
- **Description**: Authenticate user with email and password

### updateUserProfile

- **Method**: `PUT`
- **Path**: `/{id}`
- **Description**: Update user profile information

