"""Tests for UserService"""

import pytest
from fastapi.testclient import TestClient


def test_create_entity(client: TestClient):
    """Test creating a Entity"""
    response = client.post(
        "/user",
        json={"name": "Test Entity", "email": "test@example.com"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Test Entity"
    assert "id" in data


def test_get_entity(client: TestClient):
    """Test getting a Entity"""
    # First create
    create_response = client.post(
        "/user",
        json={"name": "Test Entity", "email": "test@example.com"}
    )
    created_id = create_response.json()["id"]
    
    # Then get
    response = client.get(f"/user/{created_id}")
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == created_id


def test_list_entitys(client: TestClient):
    """Test listing Entitys"""
    response = client.get("/user")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
